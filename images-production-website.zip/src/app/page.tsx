import { db } from "@/lib/db";
import { SiteHeader } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { About } from "@/components/site/about";
import { Photography } from "@/components/site/photography";
import { Films } from "@/components/site/films";
import { Categories } from "@/components/site/categories";
import { Contact } from "@/components/site/contact";
import { Footer } from "@/components/site/footer";
import { WhatsAppFloat } from "@/components/site/whatsapp-float";

async function getInitialData() {
  try {
    const [ownerRow, siteRow] = await Promise.all([
      db.ownerInfo.findFirst(),
      db.siteContent.findFirst(),
    ]);
    let owner: any = null;
    if (ownerRow) {
      let stats: any[] = [];
      try {
        stats = JSON.parse(ownerRow.stats || "[]");
      } catch {
        stats = [];
      }
      owner = {
        id: ownerRow.id,
        name: ownerRow.name,
        role: ownerRow.role,
        bio: ownerRow.bio,
        phone: ownerRow.phone,
        whatsapp: ownerRow.whatsapp,
        email: ownerRow.email,
        address: ownerRow.address,
        city: ownerRow.city,
        state: ownerRow.state,
        pincode: ownerRow.pincode,
        country: ownerRow.country,
        stats,
        photoUrl: ownerRow.photoUrl,
      };
    }
    const site = siteRow ?? {
      companyName: "IMAGES PRODUCTION",
      tagline: "Frames Alive with Imagination",
      heroHeadline: "IMAGES PRODUCTION",
      heroSubtext: "Photography • Videography • Video Editing",
      heroCtaPrimary: "VIEW OUR WORK",
      heroCtaSecondary: "CONTACT US",
      heroVideoUrl: null,
      whatsappNumber: "+91 8433975695",
      email: "hello@imagesproduction.in",
      instagram: null,
      youtube: null,
      vimeo: null,
      facebook: null,
    };
    return { owner, site };
  } catch (e) {
    // Fallback to hardcoded defaults if DB not yet seeded
    return {
      owner: null,
      site: {
        companyName: "IMAGES PRODUCTION",
        tagline: "Frames Alive with Imagination",
        heroHeadline: "IMAGES PRODUCTION",
        heroSubtext: "Photography • Videography • Video Editing",
        heroCtaPrimary: "VIEW OUR WORK",
        heroCtaSecondary: "CONTACT US",
        heroVideoUrl: null,
        whatsappNumber: "+91 8433975695",
        email: "hello@imagesproduction.in",
        instagram: null,
        youtube: null,
        vimeo: null,
        facebook: null,
      },
    };
  }
}

export default async function Home() {
  const { owner, site } = await getInitialData();
  const whatsapp = site.whatsappNumber || "+91 8433975695";

  return (
    <div className="min-h-screen flex flex-col bg-ink">
      <SiteHeader whatsapp={whatsapp} brandName={site.companyName} />
      <main className="flex-1">
        <Hero
          headline={site.heroHeadline}
          subtext={site.heroSubtext}
          tagline={site.tagline}
          primaryCta={site.heroCtaPrimary}
          secondaryCta={site.heroCtaSecondary}
          whatsapp={whatsapp}
          heroVideoUrl={site.heroVideoUrl}
        />
        <About owner={owner} whatsapp={whatsapp} />
        <Photography whatsapp={whatsapp} />
        <Films whatsapp={whatsapp} />
        <Categories whatsapp={whatsapp} />
        <Contact owner={owner} whatsapp={whatsapp} email={site.email} />
      </main>
      <Footer
        companyName={site.companyName}
        tagline={site.tagline}
        whatsapp={whatsapp}
        email={site.email}
        socials={{
          instagram: site.instagram,
          youtube: site.youtube,
          vimeo: site.vimeo,
          facebook: site.facebook,
        }}
      />
      <WhatsAppFloat
        phone={whatsapp}
        message="Hi Images Production, I'd like to discuss a project."
      />
    </div>
  );
}
