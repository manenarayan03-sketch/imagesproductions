"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { MessageCircle, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ClayServiceIcon } from "@/components/clay";
import { apiGetSafe, buildWhatsAppLink } from "@/lib/site-utils";

type Service = {
  id: string;
  title: string;
  description: string;
  icon: string;
  order: number;
};

export function Services({ whatsapp }: { whatsapp: string }) {
  const [services, setServices] = React.useState<Service[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    (async () => {
      const d = await apiGetSafe<{ services: Service[] }>("/api/services");
      if (d) setServices(d.services);
      setLoading(false);
    })();
  }, []);

  return (
    <section
      id="services"
      className="section-scroll-target relative py-24 sm:py-32 bg-[#0a0a10] overflow-hidden"
    >
      <div className="absolute top-1/3 -left-32 h-72 w-72 rounded-full bg-violet/10 blur-3xl" />
      <div className="absolute bottom-0 -right-32 h-72 w-72 rounded-full bg-electric/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 text-gold text-[10px] sm:text-xs tracking-[0.34em] uppercase">
            <span className="h-px w-8 bg-gold/60" />
            What We Craft
            <span className="h-px w-8 bg-gold/60" />
          </div>
          <h2 className="mt-5 font-heading text-cream text-4xl sm:text-5xl md:text-6xl text-balance">
            Services Offered
          </h2>
          <p className="mt-4 text-cream/65 text-base sm:text-lg">
            A complete creative toolkit — from the first frame to the final
            cut.
          </p>
        </motion.div>

        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="h-64 rounded-2xl bg-gold/5 border border-gold/10 animate-pulse"
                />
              ))
            : services.map((s, i) => (
                <motion.article
                  key={s.id}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.55, delay: (i % 3) * 0.08 }}
                  className="group relative rounded-2xl p-6 glass-card border border-gold/15 hover:border-gold/35 transition-all hover:-translate-y-1 duration-300"
                >
                  <div className="flex items-start justify-between">
                    <ClayServiceIcon icon={s.icon} size={56} />
                    <ArrowUpRight className="h-4 w-4 text-gold/40 group-hover:text-gold transition-colors" />
                  </div>
                  <h3 className="mt-6 font-heading text-cream text-xl sm:text-2xl">
                    {s.title}
                  </h3>
                  <p className="mt-3 text-cream/65 text-sm leading-relaxed line-clamp-6">
                    {s.description}
                  </p>
                  <div className="mt-6 pt-5 border-t border-gold/10">
                    <a
                      href={buildWhatsAppLink(
                        whatsapp,
                        `Hi Images Production, I'm interested in your "${s.title}" service.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-full border-gold/30 text-cream hover:text-gold hover:bg-gold/5 text-[11px] tracking-[0.16em] uppercase font-heading"
                      >
                        <MessageCircle className="h-3.5 w-3.5 mr-2" />
                        Enquire on WhatsApp
                      </Button>
                    </a>
                  </div>
                </motion.article>
              ))}
        </div>
      </div>
    </section>
  );
}
